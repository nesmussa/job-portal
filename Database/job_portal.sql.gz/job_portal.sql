-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2023 at 09:15 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `company_info`
--

CREATE TABLE `company_info` (
  `Cname` varchar(50) NOT NULL,
  `Cusername` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phoneno` varchar(13) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_info`
--

INSERT INTO `company_info` (`Cname`, `Cusername`, `Email`, `Phoneno`, `Password`) VALUES
('Yesmin', 'nes.muss', 'emileofnm@gmail.com', '988998278', 'abc@123'),
('Yesmin', 'nes.mussa', 'emileofnm@gmail.com', '988998278', 'abc@123');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `Cusername` varchar(20) NOT NULL,
  `Jobid` varchar(20) NOT NULL,
  `Jobname` varchar(50) NOT NULL,
  `Req_sex` varchar(6) NOT NULL,
  `Experience` int(11) NOT NULL,
  `Location` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`Cusername`, `Jobid`, `Jobname`, `Req_sex`, `Experience`, `Location`) VALUES
('Injibara', 'hn', 'Teacher', 'female', 2, 'Injibara'),
('Injibara', 'hn54', 'Teacher', 'female', 2, 'Injibara'),
('Injibara', 'hn545', 'Teacher', 'female', 2, 'Injibara'),
('Injibara', 'ssdsd', 'Teacher', 'male', 3, 'Injibara');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Username` varchar(20) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Lastname` varchar(50) NOT NULL,
  `Birthday` date NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(13) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Username`, `Firstname`, `Lastname`, `Birthday`, `Email`, `Phone`, `Password`) VALUES
('nes.muss', 'Nesrlah', 'Ahimed', '1970-01-01', 'emileofnm@gmail.com', '988998278', 'abc@123'),
('nes.mussa', 'Nesrlah', 'Ahimed', '1970-01-01', 'emileofnm@gmail.com', '988998278', 'abc@123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company_info`
--
ALTER TABLE `company_info`
  ADD PRIMARY KEY (`Cusername`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`Jobid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
